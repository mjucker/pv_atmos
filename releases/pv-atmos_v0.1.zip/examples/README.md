These examples show the functionality of the pv-atmos package.

example_flat.py will construct a rectangular box with zonal wind data and a full labeled grid.
example_sphere.y will construct a spherical geometry with "shells" to mimic of radial grid points.

When running the examples, be sure to set the variable pvAtmosPath to the path of the package files atmos_basic.py and atmos_grids.py.
